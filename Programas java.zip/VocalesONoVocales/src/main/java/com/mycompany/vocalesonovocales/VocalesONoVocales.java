package com.mycompany.vocalesonovocales;
import java.util.Scanner;
public class VocalesONoVocales {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        char letra;
        
        System.out.println("Ingresa letras y te diré si son vocales o consonantes. Ingresa un espacio para salir.");
        
        do {
            System.out.print("Ingresa una letra: ");
            letra = leer.next().charAt(0);
            
            if (letra == ' ') {
                System.out.println("Programa terminado.");
                break;
            }
            
            if (Character.isLetter(letra)) {
                if (esVocal(letra)) {
                    System.out.println(letra + " es una vocal.");
                } else {
                    System.out.println(letra + " es una consonante.");
                }
            } else {
                System.out.println("Por favor, ingresa solo letras.");
            }
        } while (true);

    }
    public static boolean esVocal(char letra) {
        letra = Character.toLowerCase(letra);
        return (letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u');
    }
    }