package com.mycompany.calcularlamedidadenumerospositivos;
import java.util.Scanner;
public class CalcularLaMedidaDeNumerosPositivos {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int numero;
        int suma = 0;
        int contador = 0;
        System.out.println("Ingresa números positivos uno por uno. Ingresa un número negativo para terminar.");
        
        while (true) {
            System.out.print("Ingresa un número: ");
            numero = leer.nextInt();
            if (numero < 0) {
                break;
            }
            suma += numero;
            contador++;
        }
        if (contador > 0) {
            double media = (double) suma / contador;
            System.out.println("La media de los números positivos ingresados es: " + media);
        } else {
            System.out.println("No se ingresaron números positivos.");
        }
    }
}
