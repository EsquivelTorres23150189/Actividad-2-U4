package com.mycompany.contadordenumerosimpares;
import java.util.Scanner;
public class ContadorDeNumerosImpares {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int numero;

        System.out.print("Ingrese un número entero positivo: ");
        numero = leer.nextInt();

        if (numero <= 0) {
            System.out.println("Por favor ingrese un número entero positivo.");
        } else {
            int i = 1;

            System.out.println("Números impares desde 1 hasta " + numero + ":");
            do {
                System.out.println(i);
                i += 2; 
            } while (i <= numero);
        }
    }
}
