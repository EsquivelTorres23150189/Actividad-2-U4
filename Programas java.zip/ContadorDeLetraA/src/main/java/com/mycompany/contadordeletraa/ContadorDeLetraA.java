
package com.mycompany.contadordeletraa;
import java.util.Scanner;
public class ContadorDeLetraA {

    public static void main(String[] args) {
        String palabra;
        int contador;
        Scanner leer = new Scanner(System.in);

        System.out.print("Ingrese una palabra: ");
        palabra = leer.nextLine();
        contador = 0;
        
        for (int i = 0; i < palabra.length(); i++) {
            if (palabra.charAt(i) == 'a' || palabra.charAt(i) == 'A') {
                contador++;
            }
        }
        System.out.println("La letra 'a' aparece " + contador + " veces en la palabra.");
    }
}