
package com.mycompany.conteodenumeros;
import java.util.Scanner;
public class ConteoDeNumeros {

    public static void main(String[] args) {
        int mayorque = 0 , menorque = 0, igualque = 0 , contador;
        Scanner leer = new Scanner(System.in);

        System.out.print("Ingrese la cantidad de números a ingresar: ");
        contador = leer.nextInt();
        for (int i = 0; i < contador; i++) {
            System.out.print("Ingrese un número: ");
            int number = leer.nextInt();

            if (number > 0) {
                mayorque++;
            } else if (number < 0) {
                menorque++;
            } else {
                igualque++;
            }
        }
        System.out.println("Números mayores que 0: " + mayorque);
        System.out.println("Números menores que 0: " + menorque);
        System.out.println("Números iguales a 0: " + igualque);
    }
}