package com.mycompany.calculadorabasicaconmenu;
import java.util.Scanner;
public class CalculadoraBasicaConMenu {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int opcion;
        double num1, num2, resultado;
        boolean continuar = true;

        while (continuar) {
            // Mostrar el menú
            System.out.println("Calculadora Básica");
            System.out.println("1. Sumar");
            System.out.println("2. Restar");
            System.out.println("3. Multiplicar");
            System.out.println("4. Dividir");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = leer.nextInt();

            if (opcion == 5) {
                continuar = false;
                System.out.println("¡Hasta luego!");
                break;
            }
            System.out.print("Ingrese el primer número: ");
            num1 = leer.nextDouble();
            System.out.print("Ingrese el segundo número: ");
            num2 = leer.nextDouble();

            switch (opcion) {
                case 1:
                    resultado = num1 + num2;
                    System.out.println("El resultado de la suma es: " + resultado);
                    break;
                case 2:
                    resultado = num1 - num2;
                    System.out.println("El resultado de la resta es: " + resultado);
                    break;
                case 3:
                    resultado = num1 * num2;
                    System.out.println("El resultado de la multiplicación es: " + resultado);
                    break;
                case 4:
                    if (num2 != 0) {
                        resultado = num1 / num2;
                        System.out.println("El resultado de la división es: " + resultado);
                    } else {
                        System.out.println("Error: No se puede dividir entre cero.");
                    }
                    break;
                default:
                    System.out.println("Seleccione una opción válida.");
            }
            System.out.print("¿Desea realizar otra operación? (sí/no): ");
            String respuesta = leer.next();
            if (respuesta.equalsIgnoreCase("no")) {
                continuar = false;
                System.out.println("¡Hasta luego!");
            }
        }
    }
}
