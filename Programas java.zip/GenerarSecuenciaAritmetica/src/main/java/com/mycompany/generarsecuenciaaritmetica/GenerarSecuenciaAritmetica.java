package com.mycompany.generarsecuenciaaritmetica;
import java.util.Scanner;
public class GenerarSecuenciaAritmetica {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int primernum , diferencia , numaximo , numactual;

        System.out.print("Ingrese el primer número de la secuencia: ");
        primernum = leer.nextInt();

        System.out.print("Ingrese la diferencia entre los números: ");
        diferencia = leer.nextInt();

        System.out.print("Ingrese el número máximo hasta el cual generar la secuencia: ");
        numaximo = leer.nextInt();

        if (numaximo <= primernum) {
            System.out.println("El número máximo debe ser mayor que el primer número.");
        } else {
            numactual = primernum;

            System.out.println("La secuencia aritmética es:");
            do {
                System.out.println(numactual);
                numactual += diferencia;
            } while (numactual <= numaximo);
        }
    }
}
