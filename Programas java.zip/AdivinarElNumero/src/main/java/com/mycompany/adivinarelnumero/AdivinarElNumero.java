package com.mycompany.adivinarelnumero;
import java.util.Random;
import java.util.Scanner;
public class AdivinarElNumero {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        Random ran = new Random();
        
        int numaleatorio = ran.nextInt(100) + 1;
        int intento;
        
        System.out.println("¡Bienvenido al juego de adivinanza de números!");
        System.out.println("He generado un número entre 1 y 100. ¿Puedes adivinar cuál es?");
        
        do {
            System.out.print("Ingresa tu suposición: ");
            intento = leer.nextInt();
            
            if (intento > numaleatorio) {
                System.out.println("Demasiado alto. Intenta nuevamente.");
            } else if (intento < numaleatorio) {
                System.out.println("Demasiado bajo. Intenta nuevamente.");
            } else {
                System.out.println("Has adivinado el número correctamente!!!");
            }
        } while (intento != numaleatorio);
    }
}
