package com.mycompany.generarsecuenciadecuadrados;
import java.util.Scanner;
public class GenerarSecuenciaDeCuadrados {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int num;

        System.out.print("Ingrese un número entero positivo: ");
        num = leer.nextInt();

        if (num <= 0) {
            System.out.println("Por favor ingrese un número entero positivo.");
        } else {
            int i = 1;

            System.out.println("Los cuadrados de los números desde 1 hasta " + num + " son:");
            do {
                System.out.println("El cuadrado de " + i + " es: " + (i * i));
                i++; 
            } while (i <= num);
        }
    }
}
