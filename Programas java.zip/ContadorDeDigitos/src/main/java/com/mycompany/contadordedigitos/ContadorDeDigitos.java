package com.mycompany.contadordedigitos;
import java.util.Scanner;
public class ContadorDeDigitos {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int num , contador , cont;
        
        System.out.print("Por favor, ingrese un número entero: ");
        num = leer.nextInt();
        
         contador = cont(num);
        
        System.out.println("El número ingresado tiene " + contador + " dígitos.");
    }
    public static int cont(int numero) {
        int num = 0;
        num = Math.abs(num);
        if (num == 0) {
            return 1;
        }
        return (int) Math.log10(num) + 1;
    }
}
