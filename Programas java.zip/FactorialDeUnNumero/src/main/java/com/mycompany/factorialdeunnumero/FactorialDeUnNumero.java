
package com.mycompany.factorialdeunnumero;
import java.util.Scanner;
public class FactorialDeUnNumero {

    public static void main(String[] args) {
        long factorial = 1;
        int num;
        Scanner leer = new Scanner(System.in);
        System.out.print("Ingrese un número para calcular su factorial: ");
        num = leer.nextInt();

        if (num < 0) {
            System.out.println("El factorial no está definido para números negativos.");
        } else {
            for (int i = 1; i <= num; i++) {
                factorial *= i;
            }
            System.out.println("El factorial de " + num + " es: " + factorial);
        }
    }
}